/* Copyright (c) 2012 Mi Dealer Virtual and Joze Perez */

/**
 * Anchor API
 */
var anchorApi = new function() {
// private data
	var methodsAvailable = [];
		
// private encapsulated methods
	methodsAvailable["activateEnlargeIconHover"] = function( selector, nextSelectorCat ) {
		// make image's "enlarge" icon trigger hover state when image is hovered
		$( selector ).bind( "mouseover", function() {
			if ( nextSelectorCat == "next" ) {
				$( this ).next().addClass( "hovering" );
			} else if ( nextSelectorCat == "parentParentNextNext" ) {
				$( this ).parent().parent().next().next().addClass( "hovering" );
			} else if ( nextSelectorCat == "parentParentNextSecondChild" ) {
				$( this ).parent().parent().next().children( ".btn-more" ).addClass( "hovering" );
			} else if ( nextSelectorCat == "parentPreviousSecondChild" ) {
				$( this ).parent().prev().children( ".btn-more" ).addClass( "hovering" );
			}
		} ).
		bind( "mouseout", function() {
			if ( nextSelectorCat == "next" ) {
				$( this ).next().removeClass( "hovering" );	
			} else if ( nextSelectorCat == "parentParentNextNext" ) {
				$( this ).parent().parent().next().next().removeClass( "hovering" );
			} else if ( nextSelectorCat == "parentParentNextSecondChild" ) {
				$( this ).parent().parent().next().children( ".btn-more" ).removeClass( "hovering" );
			} else if ( nextSelectorCat == "parentPreviousSecondChild" ) {
				$( this ).parent().prev().children( ".btn-more" ).removeClass( "hovering" );
			}
		} );
	};
	
// public methods
	// apply function to selected anchors
	this.addToAnchors = function( selector, nextSelectorCat, actionToAdd ) {
		if (  typeof methodsAvailable[actionToAdd] !== "undefined" ) {
			methodsAvailable[actionToAdd]( selector, nextSelectorCat );
		}
	};
};

/**
  * Feedback/Extra form API
  * -------
  * Contains all the methods that help capture data from extra forms
  */
xform_API = {
	
	_date: new Date(),
	
	_prepareEvents: function()
	{
		// onClick
		$( '#xf_close' ).click(
			function( e )
			{
				// array holding field id's
				var dropdowns = [ '#xf_model', '#xf_transmission' ];
				var fields = [ '#xf_color', '#xf_name', '#xf_telephone', '#xf_email', '#xf_message' ];
				
				// clear custom dropdowns
				$( "#xf_make" ).prev().removeClass( "invalid-field" ).children( ".center" ).text( "Marca: *" );
				$( "#xf_model" ).prev().removeClass( "invalid-field" ).children( ".center" ).text( "Modelo: *" );
				
				// clear custom fields
				for( var j = 0; j < fields.length; j++ ) {
					$( fields[j] ).removeClass( "invalid-field" ).val( $( fields[j] ).get( 0 ).defaultValue );
				}
			} );
		
		// onClick
		$( '#xf_submit' ).click(
			function( e )
			{
				// validate
				alert($('#elite-order-form').serialize());
				if( xform_API._validate() )
				{
					// clear disclaimer area
					$( '#xf_disclaimer' ).html( "" );
					
					// hide button and show loader
					$( '#xf_loader' ).removeClass( 'is-hidden' );
					$( this ).addClass( 'is-hidden' );
					
					// submit form
					$( '#elite-order-form' ).submit();
				}
				else
				{
					// send error message
					$( '#xf_disclaimer' ).html( '<span class="red"><strong>Hay casillas requeridas que a&uacute;n se encuentran vac&iacute;as.</strong></span>' );
				}
				
				// prevent default
				e.preventDefault();
				return false;
			} );
		
		// onSubmit
		$( '#elite-order-form' ).submit(
			function( e )
			{
				// parse data
				var name = $( '#xf_name' ).val().split( " " );
				
				// prepare data message
				var data = {};
				data.cid = $( '#xf_cid' ).val();
				data.subject = "<h2>Orden ELITE: Pedido de Vehiculo Nuevo</h2>";
				data.message = "<h4>Detalles de Orden Elite</h4>" +
							   "<strong>Vehiculo:</strong> Nissan " + $( '#xf_model' ).val() + " " + xform_API._date.getFullYear() + "<br />" +
							   "<strong>Color:</strong> " + $( '#xf_color' ).val() + "<br />" +
							   "<strong>Transmision:</strong> " + $( '#xf_transmission' ).val() + "<br />" +
							   "<hr />" +
							   "<strong>Otros detalles:</strong> " + $( '#xf_message' ).val() + "<br />";
				data.fname = name[0];
				data.lname = name[1];
				data.telephone = $( '#xf_telephone' ).val();
				data.email = $( '#xf_email' ).val();
				
				// send to server
				$.post( 'http://' + location.host + '/' + $( this ).attr( 'action' ),
					data,
					function( data )
					{
						// Parse returned data, and make json obj
						data = $.parseJSON( data );
						
						// Hide Loader
						$( '#xf_loader' ).addClass( 'jq_hide' );
						
						// Determine what to do
						if( data.status == 2 )
						{
							// Lock Form
							$( 'input, textarea, select', '#contactForm' ).attr( 'disabled', true );
							
							// Notify Users of new lead
							if( data.id )
							{
								// use noti_api
								noti_api.reportNewLead( data.id );
								
								// close sidebar
								$('#xf_close').trigger( 'click' );
							}
						}
						else if( data.status == 1 )
						{
							// allow resubmit
							$( '#xf_submit' ).removeClass( 'jq_hide' );
						}
						
						// Notify user
						alert( unescape( data.alert ) );
					} );
				
				// stop default behavior
				e.preventDefault();
				return false;
			} );
	},
	
	_validate: function()
	{
		// set flag
		var is_valid = true;
		var tempElem;
		
		// check conditions
		if( $( '#xf_make' ).get( 0 ).selectedIndex == 0 || $( '#xf_make option:selected' ).text() == "Marca: *" )
		{	is_valid = false; $( '#xf_make' ).prev().addClass( "invalid-field" ); }else{ $( '#xf_make' ).prev().removeClass( "invalid-field" ); }
		
		if( $( '#xf_model' ).get( 0 ).selectedIndex == 0 || $( '#xf_model option:selected' ).text() == "Modelo: *" )
		{	is_valid = false; $( '#xf_model' ).prev().addClass( "invalid-field" ); }else{ $( '#xf_model' ).prev().removeClass( "invalid-field" ); }
		
		if( $( '#xf_color' ).val() == '' || $( '#xf_color' ).val() == $( '#xf_color' ).get( 0 ).defaultValue )
		{	is_valid = false; $( '#xf_color' ).addClass( "invalid-field" ); }else{ $( '#xf_color' ).removeClass( "invalid-field" ); }
		
		if( $( '#xf_name' ).val() == '' || $( '#xf_name' ).val() == $( '#xf_name' ).get( 0 ).defaultValue )
		{	is_valid = false; $( '#xf_name' ).addClass( "invalid-field" ); }else{ $( '#xf_name' ).removeClass( "invalid-field" ); }
		
		if( $( '#xf_telephone' ).val() == '' || $( '#xf_telephone' ).val() == $( '#xf_telephone' ).get( 0 ).defaultValue )
		{	is_valid = false; $( '#xf_telephone' ).addClass( "invalid-field" ); }else{ $( '#xf_telephone' ).removeClass( "invalid-field" ); }
		
		if( $( '#xf_email' ).val() == '' || $( '#xf_email' ).val() == $( '#xf_email' ).get( 0 ).defaultValue )
		{	is_valid = false; $( '#xf_email' ).addClass( "invalid-field" ); }else{ $( '#xf_email' ).removeClass( "invalid-field" ); }
		
		if( $( '#xf_message' ).val() == '' || $( '#xf_message' ).val() == $( '#xf_message' ).get( 0 ).defaultValue )
		{	is_valid = false; $( '#xf_message' ).addClass( "invalid-field" ); }else{ $( '#xf_message' ).removeClass( "invalid-field" ); }
		
		// return verdict
		return is_valid;
	},
	
	init: function()
	{
		// prepare all events
		xform_API._prepareEvents();	
	}
	
};

/**
  * CMS API
  * -------
  * Contains all the methods that help include/execute JS in CMS pages throughout the sites
  */
var cms_API = {
	
	/* Public Methods */
	onJQReady: function( callbacks )
	{
		$( document ).ready(
			function()
			{
				/* Execute all the call backs */
				$.each( callbacks, function( index, func_to_exec )
				{ 
					func_to_exec();
				} );
			} );
	}
};

/**
  * Begin callbacks for entire site
  */
var sitewide_callbacks = [];

// Newsleter callback
sitewide_callbacks[0] =
	function()
	{
		//ajaxForms_API.detectChange();
		//newsletter_api.init();
		//logosApi.init();
	};
	
// Kill JS-Links callback
sitewide_callbacks[1] =
	function()
	{
		$( '.js-link' ).click(
			function( e ) {
				// prevent defaul click
				e.preventDefault();
			} );
	};

// Submit all sitewide callbacks
cms_API.onJQReady( sitewide_callbacks );