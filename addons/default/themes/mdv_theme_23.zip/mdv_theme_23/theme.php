<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MDV_theme_23 extends Theme {

    public $name			= 'MDV Theme 23 - CabreraAuto.com';
    public $author			= 'joze|Perez';
    public $author_website	= 'http://jozeperez.com/';
    public $website			= 'http://midealervirtual.com/';
    public $description		= 'Dealer Theme 23 - CabreraAuto.com';
    public $version			= '1.0';
	public $options 		= array();
}

/* End of file theme.php */